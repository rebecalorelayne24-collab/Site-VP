-- =====================================================================
-- Schema Postgres para Supabase — Plataforma VP (Farmácia Jr.)
-- Gerado a partir da análise do banco SQLite real (schema "vivo" em
-- produção, incluindo colunas adicionadas via ALTER TABLE em runtime).
-- Execute este arquivo inteiro no SQL Editor do Supabase, uma única vez.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. USUÁRIOS (login, RH, permissões)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id               SERIAL PRIMARY KEY,
    email            TEXT UNIQUE NOT NULL,
    senha            TEXT NOT NULL,
    nome             TEXT NOT NULL,
    departamento     TEXT DEFAULT 'Geral',
    cargo            TEXT DEFAULT 'Membro',
    foto_base64      TEXT,
    primeiro_login   INTEGER DEFAULT 1,
    status           TEXT DEFAULT 'Ativo',
    telefone         TEXT DEFAULT '',
    linkedin         TEXT DEFAULT '',
    instagram        TEXT DEFAULT '',
    data_entrada     TEXT DEFAULT '',
    data_nascimento  TEXT DEFAULT '',
    ultimo_login     TEXT DEFAULT '',
    permissoes       TEXT DEFAULT 'Membro',
    matricula        TEXT DEFAULT ''
);

-- ---------------------------------------------------------------------
-- 2. FLUXO DE CAIXA GERAL (Dashboard, Fluxo de Caixa)
--    OBS: a coluna "status_onvio" é um typo já existente no app
--    (deveria ser "status_envio"), mantido de propósito para não
--    quebrar nenhuma consulta do código atual.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fluxo_caixa_geral (
    id               SERIAL PRIMARY KEY,
    mes              TEXT,
    data             TEXT,
    departamento     TEXT,
    tipo             TEXT,
    categoria        TEXT,
    descricao        TEXT,
    valor_bruto      REAL,
    taxa             REAL,
    valor_liquido    REAL,
    conta_origem     TEXT,
    status_pagamento TEXT,
    nota_fiscal      TEXT,
    status_onvio     TEXT
);

-- ---------------------------------------------------------------------
-- 3. CONTRATOS DA EJ (Central de Negócios — Contratos & Boletos)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contratos_ej (
    id               SERIAL PRIMARY KEY,
    cliente          TEXT,
    projeto          TEXT,
    valor_total      REAL,
    parcelas_totais  INTEGER,
    parcelas_pagas   INTEGER,
    vencimento       TEXT,
    link_drive       TEXT,
    status_boleto    TEXT
);

-- ---------------------------------------------------------------------
-- 4. TAREFAS DOS ASSESSORES (Central de Negócios — Kanban)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tarefas_assessores (
    id             SERIAL PRIMARY KEY,
    tarefa         TEXT,
    assessor_nome  TEXT,
    diretoria      TEXT,
    prazo          TEXT,
    status         TEXT
);

-- ---------------------------------------------------------------------
-- 5. CADASTRO DE EVENTOS (Planejamento Estratégico de Eventos)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cadastro_eventos (
    id    SERIAL PRIMARY KEY,
    nome  TEXT UNIQUE NOT NULL
);

INSERT INTO cadastro_eventos (nome) VALUES
    ('DDA (Dia do Açaí)'),
    ('SIMCOM (Simpósio de Cosméticos)'),
    ('JOFARM (Jornada Farmacêutica)'),
    ('SEFARM (Simpósio de Farmácia)')
ON CONFLICT (nome) DO NOTHING;

-- ---------------------------------------------------------------------
-- 6. CUSTOS DOS EVENTOS
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS custos_eventos (
    id     SERIAL PRIMARY KEY,
    evento TEXT,
    item   TEXT,
    valor  REAL,
    data   TEXT,
    status TEXT DEFAULT '🟢 Pago'
);

-- ---------------------------------------------------------------------
-- 7. PATROCÍNIOS DOS EVENTOS (Captação Comercial)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patrocinios_eventos (
    id      SERIAL PRIMARY KEY,
    evento  TEXT,
    empresa TEXT,
    valor   REAL,
    data    TEXT
);

-- ---------------------------------------------------------------------
-- 8. SYMPLA CONSOLIDADO (vendas de ingressos por evento)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sympla_consolidado (
    evento              TEXT PRIMARY KEY,
    ingressos_vendidos  INTEGER,
    faturamento_bruto   REAL,
    taxa_porcentagem    REAL,
    meta_ingressos      INTEGER
);

-- ---------------------------------------------------------------------
-- 9. PLANEJAMENTO DE EVENTOS (checklist de itens/compras)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS planejamento_eventos (
    id            SERIAL PRIMARY KEY,
    evento        TEXT,
    responsavel   TEXT,
    departamento  TEXT,
    tipo_registro TEXT,
    prioridade    TEXT,
    item          TEXT,
    valor         REAL,
    status_compra TEXT
);

-- ---------------------------------------------------------------------
-- 10. LEADS / CRM EXECUTIVO (VP)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_vp_auditoria (
    id                     SERIAL PRIMARY KEY,
    empresa                TEXT UNIQUE,
    assessor               TEXT,
    valor_precificacao     REAL,
    comportamento_preco    TEXT,
    recorrencia_cliente    TEXT,
    stage_funil            TEXT DEFAULT '🎯 Lead',
    link_contrato          TEXT,
    link_termo_abertura    TEXT,
    link_termo_fechamento  TEXT,
    tipo_boleto            TEXT,
    link_boletos           TEXT,
    status_nota_fiscal     TEXT,
    data_auditoria         TEXT,
    obs_comercial          TEXT,
    obs_financeiro         TEXT,
    obs_juridico           TEXT,
    obs_licoes             TEXT,
    observacoes_vp         TEXT
);

-- ---------------------------------------------------------------------
-- 11. CAIXA DO BALCÃO (Totem de Vendas Express)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS caixa_balcao (
    id               SERIAL PRIMARY KEY,
    data_hora        TEXT,
    tipo_servico     TEXT,
    descricao        TEXT,
    cliente          TEXT,
    valor            REAL,
    diretoria        TEXT,
    status_pagamento TEXT
);

-- ---------------------------------------------------------------------
-- 12. EMPRÉSTIMOS DE JALECO (Totem)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS emprestimos_jaleco (
    id                  SERIAL PRIMARY KEY,
    data_hora           TEXT,
    cliente_nome        TEXT,
    cliente_telefone    TEXT,
    membro_responsavel  TEXT,
    status_pagamento    TEXT,
    status_devolucao    TEXT DEFAULT '🟡 Com o Aluno'
);

-- ---------------------------------------------------------------------
-- 13. VENDAS DDA / AÇAÍ (Totem)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vendas_dda (
    id            SERIAL PRIMARY KEY,
    data_hora     TEXT,
    produto       TEXT,
    cliente_nome  TEXT,
    valor         REAL,
    diretoria     TEXT
);

-- ---------------------------------------------------------------------
-- 14. VENDAS DE SOUVENIRS (Totem)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vendas_souvenirs (
    id            SERIAL PRIMARY KEY,
    data_hora     TEXT,
    item          TEXT,
    cliente_nome  TEXT,
    valor         REAL,
    diretoria     TEXT
);

-- ---------------------------------------------------------------------
-- 15. REGISTRO DE IMPRESSÕES / XEROX (Totem)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS registro_impressoes (
    id            SERIAL PRIMARY KEY,
    data_hora     TEXT,
    cliente_nome  TEXT,
    paginas       INTEGER,
    valor         REAL,
    diretoria     TEXT
);

-- =====================================================================
-- Seed: contas padrão de diretoria (senha inicial 123456 — a plataforma
-- já força a troca de senha no primeiro login, primeiro_login = 1)
-- =====================================================================
INSERT INTO usuarios (email, senha, nome, departamento, cargo, primeiro_login, status)
VALUES
    ('vice-presidencia@farmaciajr.com', '123456', 'Vice-Presidência', 'VP', 'Diretor(a)', 1, 'Ativo'),
    ('presidencia@farmaciajr.com', '123456', 'Presidência', 'Presidência', 'Diretor(a)', 1, 'Ativo')
ON CONFLICT (email) DO NOTHING;
